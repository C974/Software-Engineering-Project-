import java.util.ArrayList;

public class Author 
{
	String name;
	String email;
	ArrayList<Paper> papers = new ArrayList<Paper>();
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the papers
	 */
	public ArrayList<Paper> getPapers() {
		return papers;
	}
	/**
	 * @param papers the papers to set
	 */
	public void setPapers(ArrayList<Paper> papers) {
		this.papers = papers;
	}
	/**
	 * @param name
	 * @param email
	 * @param papers
	 */
	public Author(String name, String email, ArrayList<Paper> papers) {
		super();
		this.name = name;
		this.email = email;
		this.papers = papers;
	}
	@Override
	public String toString() {
		return "Author [name=" + name + ", email=" + email + ", papers=" + papers + "]";
	}
	
	public void SubmitArticle(Paper p)
	{
		papers.add(p);
	}

}
