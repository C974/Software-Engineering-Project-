import java.util.ArrayList;

public class Paper 
{
	String title;
	String absract;
	String keywords;
	String moviewviewrs;
	String ststaus;
	ArrayList<Author> authors = new ArrayList<Author>();

	public ArrayList<Author> getAuthors()
	{
		return authors;
	}
}
